package softuni.exam.models.entity;

public enum StarTypes {
    RED_GIANT, WHITE_DWARF, NEUTRON_STAR
}
