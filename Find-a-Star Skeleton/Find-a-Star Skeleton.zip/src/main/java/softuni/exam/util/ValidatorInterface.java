package softuni.exam.util;

public interface ValidatorInterface {
    <E> boolean isValid(E entity);
}
